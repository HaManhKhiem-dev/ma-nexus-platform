import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

export const resources = {
  en: {
    translation: {
      navbar: {
        brand: 'Nexus',
        brand_subtitle: 'Institutional',
        marketplace: 'Marketplace',
        dashboard: 'Dashboard',
        data_room: 'Data Room',
        submit_deal: 'Submit Deal',
        admin: 'Admin',
        profile_kyc: 'Profile & KYC',
        sign_in: 'Sign In',
        log_out: 'Log Out',
        kyc_locked_banner: 'Your workspace is locked until KYC is verified. Complete CCCD and face verification to unlock protected features.',
        go_to_kyc: 'Go To KYC',
        footer_copyright: '© 2026 M&A Nexus // Terminal V4',
        kyc_gated: 'KYC Gated',
        encrypted: 'Encrypted',
        rbac_enabled: 'RBAC Enabled',
        lang_en: 'EN',
        lang_vi: 'VI',
        switch_to_english: 'Switch to English',
        switch_to_vietnamese: 'Switch to Vietnamese',
        kyc_required_title: 'KYC verification required'
      },
      auth: {
        terminal: 'NexusM&A Secure Terminal',
        title_login: 'Secure Access',
        title_register: 'Create Account',
        title_otp: 'Verify Email',
        secure_description: 'Access is protected for verified investors, sellers, advisors, and compliance admins.',
        otp_description: 'Enter the verification code sent to {{email}}.',
        full_name: 'Full Name',
        corporate_email: 'Corporate Email',
        access_key: 'Access Key',
        verification_code: 'Verification Code',
        otp_placeholder: '000000',
        processing: 'Processing...',
        enter_workspace: 'Enter Workspace',
        send_verification: 'Send Verification',
        confirm_account: 'Confirm Account',
        or_continue_with: 'Or Continue With',
        google_sso: 'Google SSO',
        back_to_register: 'Back To Register',
        register_switch: 'New Operator? Register',
        sign_in_switch: 'Already Authorized? Sign In',
        sign_in_required: 'Sign In Required',
        secure_access_only: 'Secure Access Only',
        sign_in_before_accessing: 'Please sign in before accessing this protected workspace.',
        sign_in: 'Sign In',
        route_not_found: 'Route Not Found',
        page_not_exist: 'This Page Does Not Exist',
        route_unavailable: 'The route you requested is not available in this workspace.',
        back_to_home: 'Back To Home',
        authorized_user: 'Authorized'
      },
      home: {
        hero_badge: 'Institutional M&A Ecosystem',
        hero_title_line_1: 'Verified',
        hero_title_gradient: 'Transaction',
        hero_title_line_3: 'Intelligence.',
        hero_description: 'A secure workspace for private market deals with KYC-gated access, protected data rooms, role-based workflows, and compliance review.',
        cta_initialize_access: 'Initialize Access',
        cta_enter_marketplace: 'Enter Marketplace',
        cta_complete_kyc: 'Complete KYC',
        submit_asset: 'Submit Asset',
        deal_operating_system: 'Deal Operating System',
        compliance_layer: 'Compliance Layer',
        lifecycle: {
          listing_label: 'Listing',
          listing_value: 'Strategic asset profiling',
          matching_label: 'Matching',
          matching_value: 'Proprietary fit scoring',
          diligence_label: 'Diligence',
          diligence_value: 'NDA-gated data vaults',
          negotiation_label: 'Negotiation',
          negotiation_value: 'Dynamic offer management',
          legal_label: 'Legal',
          legal_value: 'Digital SPA orchestration',
          closing_label: 'Closing',
          closing_value: 'Final asset settlement'
        },
        metrics: {
          verified_users_label: 'Verified Users',
          verified_users_value: 'KYC Gate',
          deal_flow_label: 'Deal Flow',
          deal_flow_value: 'Private Access',
          data_rooms_label: 'Data Rooms',
          data_rooms_value: 'Encrypted',
          compliance_label: 'Compliance',
          compliance_value: 'Admin Review'
        }
      },
      roles: {
        buyer: 'Buyer',
        seller: 'Seller',
        advisor: 'Advisor',
        admin: 'Admin'
      },
      kyc: {
        verified_label: 'Verified',
        verified_description: 'Identity verified. Full workspace access is enabled.',
        pending_label: 'In Review',
        pending_description: 'KYC has been submitted and is waiting for admin review.',
        rejected_label: 'Rejected',
        rejected_description: 'KYC was rejected. Please resubmit CCCD and face verification.',
        not_verified_label: 'Not Verified',
        not_verified_description: 'Complete KYC before using private deal features.',
        status_with_label: 'KYC Status: {{label}}',
        required_eyebrow: 'KYC Required',
        verification_required: 'Verification Required',
        required_description: 'You need verified KYC before using marketplace functions, deal submission, dashboard, data room, and private deal workflows.',
        complete_kyc: 'Complete KYC',
        current_status: 'Current status: {{status}}',
        verification_required_short: 'KYC verification required'
      },
      common: {
        loading_initializing_nexus: 'Initializing Nexus'
      }
    }
  },
  vi: {
    translation: {
      navbar: {
        brand: 'Nexus',
        brand_subtitle: 'Tổ chức',
        marketplace: 'Thị trường',
        dashboard: 'Bảng điều khiển',
        data_room: 'Phòng dữ liệu',
        submit_deal: 'Gửi thương vụ',
        admin: 'Quản trị',
        profile_kyc: 'Hồ sơ & KYC',
        sign_in: 'Đăng nhập',
        log_out: 'Đăng xuất',
        kyc_locked_banner: 'Không gian làm việc của bạn bị khóa cho đến khi KYC được xác minh. Hoàn tất xác thực CCCD và khuôn mặt để mở khóa các tính năng được bảo vệ.',
        go_to_kyc: 'Đến KYC',
        footer_copyright: '© 2026 M&A Nexus // Terminal V4',
        kyc_gated: 'Yêu cầu KYC',
        encrypted: 'Đã mã hóa',
        rbac_enabled: 'Đã bật RBAC',
        lang_en: 'EN',
        lang_vi: 'VI',
        switch_to_english: 'Chuyển sang tiếng Anh',
        switch_to_vietnamese: 'Chuyển sang tiếng Việt',
        kyc_required_title: 'Cần xác minh KYC'
      },
      auth: {
        terminal: 'Cổng bảo mật NexusM&A',
        title_login: 'Truy cập bảo mật',
        title_register: 'Tạo tài khoản',
        title_otp: 'Xác minh email',
        secure_description: 'Quyền truy cập được bảo vệ cho nhà đầu tư, bên bán, cố vấn và quản trị tuân thủ đã xác minh.',
        otp_description: 'Nhập mã xác minh đã gửi đến {{email}}.',
        full_name: 'Họ và tên',
        corporate_email: 'Email doanh nghiệp',
        access_key: 'Mật khẩu truy cập',
        verification_code: 'Mã xác minh',
        otp_placeholder: '000000',
        processing: 'Đang xử lý...',
        enter_workspace: 'Vào không gian làm việc',
        send_verification: 'Gửi mã xác minh',
        confirm_account: 'Xác nhận tài khoản',
        or_continue_with: 'Hoặc tiếp tục với',
        google_sso: 'Google SSO',
        back_to_register: 'Quay lại đăng ký',
        register_switch: 'Người dùng mới? Đăng ký',
        sign_in_switch: 'Đã được cấp quyền? Đăng nhập',
        sign_in_required: 'Yêu cầu đăng nhập',
        secure_access_only: 'Chỉ truy cập bảo mật',
        sign_in_before_accessing: 'Vui lòng đăng nhập trước khi truy cập không gian làm việc được bảo vệ này.',
        sign_in: 'Đăng nhập',
        route_not_found: 'Không tìm thấy tuyến',
        page_not_exist: 'Trang này không tồn tại',
        route_unavailable: 'Tuyến bạn yêu cầu không có trong không gian làm việc này.',
        back_to_home: 'Về trang chủ',
        authorized_user: 'Đã xác thực'
      },
      home: {
        hero_badge: 'Hệ sinh thái M&A dành cho tổ chức',
        hero_title_line_1: 'Xác minh',
        hero_title_gradient: 'Giao dịch',
        hero_title_line_3: 'Thông minh.',
        hero_description: 'Không gian làm việc bảo mật cho các thương vụ thị trường tư nhân với truy cập qua KYC, phòng dữ liệu được bảo vệ, quy trình theo vai trò và rà soát tuân thủ.',
        cta_initialize_access: 'Khởi tạo truy cập',
        cta_enter_marketplace: 'Vào thị trường',
        cta_complete_kyc: 'Hoàn tất KYC',
        submit_asset: 'Gửi tài sản',
        deal_operating_system: 'Hệ điều hành thương vụ',
        compliance_layer: 'Lớp tuân thủ',
        lifecycle: {
          listing_label: 'Niêm yết',
          listing_value: 'Lập hồ sơ tài sản chiến lược',
          matching_label: 'Ghép nối',
          matching_value: 'Chấm điểm mức độ phù hợp độc quyền',
          diligence_label: 'Thẩm định',
          diligence_value: 'Kho dữ liệu có kiểm soát NDA',
          negotiation_label: 'Đàm phán',
          negotiation_value: 'Quản lý đề nghị linh hoạt',
          legal_label: 'Pháp lý',
          legal_value: 'Điều phối SPA số',
          closing_label: 'Hoàn tất',
          closing_value: 'Tất toán tài sản cuối cùng'
        },
        metrics: {
          verified_users_label: 'Người dùng đã xác minh',
          verified_users_value: 'Cổng KYC',
          deal_flow_label: 'Luồng thương vụ',
          deal_flow_value: 'Truy cập riêng tư',
          data_rooms_label: 'Phòng dữ liệu',
          data_rooms_value: 'Đã mã hóa',
          compliance_label: 'Tuân thủ',
          compliance_value: 'Quản trị rà soát'
        }
      },
      roles: {
        buyer: 'Bên mua',
        seller: 'Bên bán',
        advisor: 'Cố vấn',
        admin: 'Quản trị'
      },
      kyc: {
        verified_label: 'Đã xác minh',
        verified_description: 'Danh tính đã được xác minh. Toàn bộ quyền truy cập không gian làm việc đã được bật.',
        pending_label: 'Đang xét duyệt',
        pending_description: 'KYC đã được gửi và đang chờ quản trị viên xét duyệt.',
        rejected_label: 'Bị từ chối',
        rejected_description: 'KYC bị từ chối. Vui lòng gửi lại CCCD và xác minh khuôn mặt.',
        not_verified_label: 'Chưa xác minh',
        not_verified_description: 'Hoàn tất KYC trước khi sử dụng các tính năng thương vụ riêng tư.',
        status_with_label: 'Trạng thái KYC: {{label}}',
        required_eyebrow: 'Yêu cầu KYC',
        verification_required: 'Cần xác minh',
        required_description: 'Bạn cần KYC đã được xác minh trước khi sử dụng chức năng thị trường, gửi thương vụ, bảng điều khiển, phòng dữ liệu và quy trình thương vụ riêng tư.',
        complete_kyc: 'Hoàn tất KYC',
        current_status: 'Trạng thái hiện tại: {{status}}',
        verification_required_short: 'Cần xác minh KYC'
      },
      common: {
        loading_initializing_nexus: 'Đang khởi tạo Nexus'
      }
    }
  }
} as const;

i18n.use(initReactI18next).init({
  resources,
  lng: 'en',
  fallbackLng: 'en',
  interpolation: {
    escapeValue: false
  }
});

export default i18n;
